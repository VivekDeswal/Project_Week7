package weather;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class toptenq3 {
public static class Maphightemp extends Mapper<LongWritable, Text, DoubleWritable, Text>{
		
	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{
		
		String line = value.toString();
		String [] st=line.split("\\s+");
		String date = st[1];
		String tmax = st[5];
		String tmin = st[6];
		

		double maxTemp = Double.parseDouble(tmax);
		double minTemp = Double.parseDouble(tmin);

		con.write(new DoubleWritable(minTemp), new Text(date));
		con.write(new DoubleWritable(maxTemp), new Text(date));
		}
	}
		public static class ReduceFortemp extends Reducer< DoubleWritable, Text, DoubleWritable,Text>{
			TreeMap<DoubleWritable, Text> coldTemp = new TreeMap<DoubleWritable, Text>();
			 TreeMap<DoubleWritable, Text> highTemp = new TreeMap<DoubleWritable, Text>();
			 int i = 0;
		public void reduce(DoubleWritable key, Iterable<Text> values, Context con) throws IOException, InterruptedException{
			
			double temp = key.get();
			String date = values.iterator().next().toString();

			
			if (i < 10) {
				coldTemp.put(new DoubleWritable(temp), new Text(date));
				++i;
			}

			
			highTemp.put(new DoubleWritable(temp), new Text(date));
			if (highTemp.size() > 10) {
				
				highTemp.remove(highTemp.keySet().iterator().next());
		}
		}
		
		public void cleanup(Context con) throws IOException, InterruptedException {

	con.write(null, new Text("Top 10 Coldest Days: "));
	for (Entry<DoubleWritable, Text> m : coldTemp.entrySet()) {
		con.write(m.getKey(), m.getValue());
	}

	con.write(null, new Text("Top 10 Hottest Days: "));
	List<DoubleWritable> highTempKeys = new ArrayList<DoubleWritable>(
			highTemp.keySet());
	Collections.reverse(highTempKeys);

	for (int i = 0; i < highTempKeys.size(); i++) {
		con.write(highTempKeys.get(i), highTemp.get(highTempKeys.get(i)));
	}
}

}
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
			Configuration conf= new Configuration();
			Job j=Job.getInstance(conf,"Max and Min Temp");
			j.setJarByClass(toptenq3.class);
			j.setMapperClass(Maphightemp.class);
			j.setReducerClass(ReduceFortemp.class);
			j.setOutputKeyClass(DoubleWritable.class);
			j.setOutputValueClass(Text.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
		}

}
