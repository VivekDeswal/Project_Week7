package weather;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class daytempq2 {

	public static class Maphightemp extends Mapper<LongWritable, Text, Text, FloatWritable>{
		
		public void map(LongWritable key,Text value, Context con)throws IOException, InterruptedException{
			String line =value.toString();
			String[] st=line.split("\\s+");
			
			String t=st[1];
			float tmax=Float.parseFloat(st[5]);
			float tmin=Float.parseFloat(st[6]);
			
			FloatWritable maxtemp= new FloatWritable(tmax);
			FloatWritable mintemp= new FloatWritable(tmin);
		if(tmin<10){
			con.write(new Text("Cold Day "+t),mintemp);
		}
		if(tmax>35){
			con.write(new Text("Hot Day "+t),maxtemp);
		}
		}
	}
		public static class ReduceForhtemp extends Reducer<Text, Text, Text, Text>{
		public void reduce(Text lines, Iterator<Text> values, Context con) throws IOException, InterruptedException{
			
			String result= values.next().toString();
			con.write(lines, new Text(result));
			
		}
		}
		
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
			Configuration conf= new Configuration();
			Job j=Job.getInstance(conf,"Highest Temp");
			j.setJarByClass(daytempq2.class);
			j.setMapperClass(Maphightemp.class);
			j.setReducerClass(ReduceForhtemp.class);
			j.setOutputKeyClass(Text.class);
			j.setOutputValueClass(FloatWritable.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
		}
}
