package weather;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class daytempq4 {

	public static class MapTemp extends Mapper<LongWritable, Text, Text, Text>
    {
            public void map(LongWritable key, Text value, Context con) throws
IOException, InterruptedException{

                    String line=value.toString();
                    String[] st=line.split("\\s+"); 
                   
                    String t=st[1];

                    String tmax=st[5];
                    String tmin=st[6];
                    con.write(new Text(t),new Text(tmax+"\t"+tmin) ); 


            }
    }
    public static class ReduceTemp extends Reducer<Text, Text, Text, Text>{
            public void reduce (Text lines, Iterator<Text> values, Context
con)throws IOException, InterruptedException{

                    String output=values.next().toString();
                    con.write(lines, new Text(output));
            }
    }

    public static void main(String[] args) throws IOException,
ClassNotFoundException, InterruptedException{
            Configuration conf= new Configuration();
            Job j=Job.getInstance(conf,"max and min Temp");
            j.setJarByClass(daytempq4.class);
            j.setMapperClass(MapTemp.class);
            j.setReducerClass(ReduceTemp.class);
            j.setOutputKeyClass(Text.class);
            j.setOutputValueClass(Text.class); //output in Text
            FileInputFormat.addInputPath(j, new Path(args[0]));
            FileOutputFormat.setOutputPath(j, new Path(args[1]));
            System.exit(j.waitForCompletion(true)?0:1);
    }}
