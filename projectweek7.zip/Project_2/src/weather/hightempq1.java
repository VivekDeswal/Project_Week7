package weather;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class hightempq1 {

	public static class Maphightemp extends Mapper<LongWritable, Text, Text, FloatWritable>{
		
		public void map(LongWritable key,Text value, Context con)throws IOException, InterruptedException{
			String line =value.toString();
			String[] st=line.split("\\s+");
			
			String t=st[1];
			Text year= new Text((t.substring(0,4)));
			
			float htemp= Float.parseFloat(st[5]);
			FloatWritable fw =new FloatWritable(htemp);
			con.write(year, fw);
		}
	}
		public static class ReduceForhtemp extends Reducer<Text, FloatWritable, Text, FloatWritable>{
		public void reduce(Text lines, Iterable<FloatWritable> values, Context con) throws IOException, InterruptedException{
			
			float sum=(float) 0.0;
			for (FloatWritable value:values){
				float fw=value.get();
				if(fw>sum){
					sum=fw;
				}
			}
			con.write(lines, new FloatWritable(sum));
		}
		}
		
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
			Configuration conf= new Configuration();
			Job j=Job.getInstance(conf,"Highest Temp");
			j.setJarByClass(hightempq1.class);
			j.setMapperClass(Maphightemp.class);
			j.setReducerClass(ReduceForhtemp.class);
			j.setOutputKeyClass(Text.class);
			j.setOutputValueClass(FloatWritable.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
		}
}
